import numpy as np
import matplotlib.pyplot as plt

sieveSize =np.array([4.75, 2, 0.85, 0.425, 0.25, 0.15, 0.075])
percentPassed=np.array([100, 95.2, 84.2, 61.4, 41.6, 20.4, 6.9 ])
plt.figure(figsize=(8.5,6))
plt.semilogx(sieveSize , percentPassed)
plt.xlim(5,0.08)
plt.title('Particle Size Distribution Curve for Soil Sample')
plt.xlabel('sieve size(mm)')
plt.ylabel('percentage passed(%)')
plt.tight_layout()
plt.savefig('6948021-2.png')
plt.show()
