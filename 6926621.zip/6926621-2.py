import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
Data = pd.read_csv('Accident Data.csv')
Data.to_csv('Accident Data.csv', index=True)
fatality=np.array(Data['Fatality'])
SevereInjury = np.array(Data['Severe injury'])
MinorInjury = np.array(Data['Minor injury'])
PersonsAffected = fatality + SevereInjury + MinorInjury
Data['PersonsAffected']= PersonsAffected
Data.to_csv('6948021.csv')
plt.figure(figsize=(8.5,6))
plt.subplot(2,1,1)
plt.plot('Year','PersonsAffected',data=Data)
plt.xlabel('Year')
plt.ylabel('PersonsAffected')
plt.subplot(2,1,2)
plt.plot('Year','Fatality',data=Data)
plt.xlabel('year')
plt.ylabel('Fatality')
fig,ax1=plt.subplots(figsize=(8.5,6))
ax1.plot('Year', 'Fatality', data=Data)
ax2 = ax1.twinx()
ax2.plot('Year', 'PersonsAffected', data=Data)
plt.title('Accident Data Graph')
ax1.set_ylabel('Fatality')
ax2.set_ylabel('Persons Affected')
plt.savefig('6948021.png')
plt.show()